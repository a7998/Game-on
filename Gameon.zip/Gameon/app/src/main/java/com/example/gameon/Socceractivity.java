package com.example.gameon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class Socceractivity extends AppCompatActivity {

   CardView cdx;
   CardView cdx1;
   CardView cdx2;
   CardView cdx3;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socceractivity);
        cdx=findViewById(R.id.cdx);
        cdx1=findViewById(R.id.cdx1);
        cdx2=findViewById(R.id.cdx2);
        cdx3=findViewById(R.id.cdx3);




    }
}